"use client";

import { useState } from "react";

export default function ContactForm() {
  const [sent, setSent] = useState(false);
  return <form className="contact-form" onSubmit={(event) => { event.preventDefault(); setSent(true); }}>
    <div className="field-row"><label>Full Name<input name="name" required placeholder="Your name"/></label><label>Phone / WhatsApp<input name="phone" required placeholder="03XX XXXXXXX"/></label></div>
    <div className="field-row"><label>Email Address<input name="email" type="email" required placeholder="you@example.com"/></label><label>Preferred Destination<select name="destination" defaultValue=""><option value="" disabled>Select a destination</option><option>Swat, Kalam & Malam Jabba</option><option>Hunza & Khunjerab Pass</option><option>Mushkpuri Top</option><option>Kumrat & Jahaz Banda</option><option>Custom journey</option></select></label></div>
    <div className="field-row"><label>Travel Month<input name="month" type="month"/></label><label>Travelers<select name="travelers" defaultValue="2"><option value="1">1 Traveler</option><option value="2">2 Travelers</option><option value="4">3–4 Travelers</option><option value="6">5–8 Travelers</option><option value="9">9+ Travelers</option></select></label></div>
    <label>Tell Us About Your Trip<textarea name="message" rows={5} required placeholder="Dates, interests, preferred pace or anything else we should know..."></textarea></label>
    <button className="button button-gold" type="submit">Send Trip Enquiry</button>
    {sent && <p className="form-success" role="status">Thank you! Your enquiry is ready. Our team will contact you shortly.</p>}
  </form>;
}
